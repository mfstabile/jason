package jason.util;

public interface ToJSON {
    public String getAsJSON(String identation);
}
